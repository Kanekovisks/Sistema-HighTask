package com.example.hightask;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

/**
 * Adapter para exibir a lista de Chamados no RecyclerView.
 */
public class ChamadoAdapter extends RecyclerView.Adapter<ChamadoAdapter.ChamadoViewHolder> {

    private final List<Chamado> listaChamados;
    private final Context context;

    public ChamadoAdapter(Context context, List<Chamado> listaChamados) {
        this.context = context;
        this.listaChamados = listaChamados;
    }

    @NonNull
    @Override
    public ChamadoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Infla o layout item_chamado.xml
        // Certifique-se de que R.layout.item_chamado está definido
        View view = LayoutInflater.from(context).inflate(R.layout.item_chamado, parent, false);
        return new ChamadoViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ChamadoViewHolder holder, int position) {
        Chamado chamado = listaChamados.get(position);

        // Mapeia os dados do modelo para os TextViews do layout
        holder.textTitulo.setText(chamado.getTitulo());
        holder.textId.setText("#" + chamado.getId());
        holder.textDescricao.setText(chamado.getDescricao());
        holder.textStatus.setText(chamado.getStatus());

        // Combina Criador e Data para o Rodapé
        String rodape = String.format("Criado por: %s | %s", chamado.getCriador(), chamado.getDataHora());
        holder.textRodape.setText(rodape);

        // Define a prioridade
        String prioridade = chamado.getPrioridade();
        holder.textPrioridade.setText(prioridade);

        // --- CORREÇÃO DO BLOCO DE ERRO: Inicializa com o valor padrão ---
        // ATENÇÃO: Os Drawables (R.drawable.fundo_prioridade_xxx) PRECISAM existir.

        // 1. Inicializa com o valor padrão (baixa)
        int backgroundDrawableId = R.drawable.fundo_prioridade_baixa;

        // 2. Define o ícone de alerta como oculto por padrão
        if (holder.iconAlerta != null) {
            holder.iconAlerta.setVisibility(View.GONE);
        }

        // 3. Usa o switch para tratar apenas os casos ALTA e MEDIA
        switch (prioridade.toLowerCase()) {
            case "alta":
                backgroundDrawableId = R.drawable.fundo_prioridade_alta;
                if (holder.iconAlerta != null) {
                    holder.iconAlerta.setVisibility(View.VISIBLE); // Exibe para Alta
                }
                break;
            case "media":
                backgroundDrawableId = R.drawable.fundo_prioridade_media;
                // Para Média e Baixa, o ícone já está GONE (oculto)
                break;
            // O caso "baixa" e o "default" usam o valor inicializado
        }
        // --- FIM DA CORREÇÃO ---

        // Define o background para o TextView de Prioridade (usa o valor garantidamente inicializado)
        holder.textPrioridade.setBackground(ContextCompat.getDrawable(context, backgroundDrawableId));

        // Define a cor do Status (simulado)
        int statusColor;
        switch (chamado.getStatus().toLowerCase()) {
            case "aberto":
                statusColor = Color.parseColor("#FFC107"); // Amarelo
                break;
            case "fechado":
                statusColor = Color.parseColor("#4CAF50"); // Verde
                break;
            case "em andamento":
            default:
                statusColor = Color.parseColor("#2196F3"); // Azul
                break;
        }
        holder.textStatus.setTextColor(statusColor);
    }

    @Override
    public int getItemCount() {
        return listaChamados.size();
    }

    /**
     * ViewHolder: Mapeia as views do item_chamado.xml
     */
    public static class ChamadoViewHolder extends RecyclerView.ViewHolder {
        public TextView iconAlerta;
        public TextView textTitulo;
        public TextView textId;
        public TextView textPrioridade;
        public TextView textDescricao;
        public TextView textStatus;
        public TextView textRodape;

        public ChamadoViewHolder(View view) {
            super(view);
            // Mapeamento dos IDs do item_chamado.xml
            iconAlerta = view.findViewById(R.id.icon_alerta);
            textTitulo = view.findViewById(R.id.text_titulo);
            textId = view.findViewById(R.id.text_id);
            textPrioridade = view.findViewById(R.id.text_prioridade);
            textDescricao = view.findViewById(R.id.text_descricao);
            textStatus = view.findViewById(R.id.text_status);
            textRodape = view.findViewById(R.id.text_rodape);

            // Listener de clique para abrir os detalhes do chamado
            view.setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION) {
                    // Implemente aqui o Intent para iniciar a DetalhesActivity
                    // Context context = v.getContext();
                    // Chamado chamadoClicado = ((ChamadoAdapter) getBindingAdapter()).listaChamados.get(position);
                    // Intent intent = new Intent(context, DetalhesActivity.class);
                    // intent.putExtra("CHAMADO_ID", chamadoClicado.getId());
                    // context.startActivity(intent);
                }
            });
        }
    }
}