package com.example.hightask;

import android.os.Bundle;
import android.widget.ImageButton;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

/**
 * Activity responsável por exibir a lista de Chamados usando o RecyclerView.
 * Corresponde ao layout activity_relatorio.xml.
 */
public class FormRelatorio extends AppCompatActivity {

    private ImageButton btnVoltar;
    private RecyclerView recyclerViewChamados;
    private ChamadoAdapter adapter;
    private List<Chamado> listaChamados;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Define o layout XML para esta Activity
        setContentView(R.layout.activity_form_relatorio);

        // 1. Inicializa as Views
        btnVoltar = findViewById(R.id.btn_voltar);
        recyclerViewChamados = findViewById(R.id.recycler_view_chamados);

        // 2. Configura o Botão Voltar
        setupBotaoVoltar();

        // 3. Carrega e Exibe os Dados (RecyclerView)
        carregarDadosEConfigurarRecyclerView();
    }

    /**
     * Configura o listener para o botão de voltar, que fecha a Activity.
     */
    private void setupBotaoVoltar() {
        btnVoltar.setOnClickListener(v -> {
            // Fecha a Activity atual e retorna para a anterior (geralmente o Menu)
            finish();
        });
    }

    /**
     * Cria dados de exemplo e configura o RecyclerView com o Adapter.
     */
    private void carregarDadosEConfigurarRecyclerView() {
        // --- 1. Criar Dados de Exemplo (Simulação de chamada a um banco de dados/API) ---
        listaChamados = new ArrayList<>();
        listaChamados.add(new Chamado("a1b2c3d4", "Falha de Rede no Servidor Principal", "O servidor de dados caiu e a rede não está respondendo. Urgente!", "Alta", "Em Andamento", "João da Silva", "28/11/2025 10:30"));
        listaChamados.add(new Chamado("e5f6g7h8", "Solicitação de Instalação de Novo Software", "Precisamos do software 'Project Manager Pro' instalado nas máquinas do RH.", "Baixa", "Aberto", "Maria Souza", "27/11/2025 15:45"));
        listaChamados.add(new Chamado("i9j0k1l2", "Problema de Impressora no 3º Andar", "A impressora HP 4000 do setor de vendas está com papel atolado.", "Media", "Fechado", "Pedro Alves", "26/11/2025 09:00"));
        listaChamados.add(new Chamado("m3n4o5p6", "Dúvida sobre Acesso ao VPN Corporativo", "Não consigo me conectar à VPN fora do escritório. Necessito de ajuda.", "Media", "Em Andamento", "Ana Costa", "28/11/2025 12:00"));
        listaChamados.add(new Chamado("q7r8s9t0", "Upgrade de Memória no PC do CEO", "Solicitação para dobrar a memória RAM do computador do CEO.", "Alta", "Aberto", "Equipe T.I.", "25/11/2025 18:00"));
        // Em um aplicativo real, este é o ponto onde você faria a chamada a uma API ou Banco de Dados (ex: Firebase, Room, etc.)

        // --- 2. Configurar o Adapter e o RecyclerView ---
        adapter = new ChamadoAdapter(this, listaChamados);

        // O LayoutManager já está definido no XML (app:layoutManager), então só definimos o adapter.
        recyclerViewChamados.setAdapter(adapter);
    }
}