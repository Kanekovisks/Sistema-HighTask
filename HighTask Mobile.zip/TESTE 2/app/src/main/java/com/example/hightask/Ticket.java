package com.example.hightask;

import java.util.List;

public class Ticket {
    private String id;
    private String title;
    private String description;
    private String category;
    private String priority;
    private String status;
    private String createdByname;
    // CORREÇÃO: Usando a classe interna 'TimelineEntry'
    private List<TimelineEntry> timeline;

    // Construtor vazio (necessário para Gson)
    public Ticket() {}

    // Getters
    public String getId() { return id; }
    public String getTitle() { return title; }
    // ... outros getters

    // CORREÇÃO APLICADA: TimelineEntry definida como 'public static class'
    public static class TimelineEntry {
        private String id; // Adicionado com base na interface TypeScript
        private String action; // 'created' | 'updated' | 'comment'
        private String description;
        private String userId;
        private String userName;
        private String timestamp;

        // Construtor vazio (necessário para Gson)
        public TimelineEntry() {}

        // Getters
        public String getAction() { return action; }
        public String getDescription() { return description; }
        // ... outros getters
    }
}