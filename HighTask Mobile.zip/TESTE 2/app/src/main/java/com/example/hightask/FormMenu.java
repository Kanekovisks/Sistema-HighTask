package com.example.hightask;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;


public class FormMenu extends AppCompatActivity {

    private CardView cardNovoChamado;
    private CardView cardChamadosAntigos;
    private CardView cardPerfil;
    private Button btnLogout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_form_menu);

        inicializarComponentes();

        configurarListeners();
    }

    private void inicializarComponentes() {
        cardNovoChamado = findViewById(R.id.card_novo_chamado);
        cardChamadosAntigos = findViewById(R.id.card_chamados_antigos);
        cardPerfil = findViewById(R.id.card_perfil);

        btnLogout = findViewById(R.id.btn_logout);
    }

    private void configurarListeners() {

        cardNovoChamado.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navegarParaActivity(NovoChamadoActivity.class);
            }
        });


        cardChamadosAntigos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navegarParaActivity(FormRelatorio.class);
            }
        });


        cardPerfil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navegarParaActivity(TelaPincipal.class);
            }
        });

        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                realizarLogout();
            }
        });
    }

    private void navegarParaActivity(Class<?> targetActivity) {
        Intent intent = new Intent(FormMenu.this, targetActivity);
        startActivity(intent);

    }

    private void realizarLogout() {

        Toast.makeText(this, "Sessão encerrada. Retornando ao Login.", Toast.LENGTH_SHORT).show();

        Intent intent = new Intent(FormMenu.this, FormLoginActivity.class);

        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);

        finish();
    }
}