package com.example.hightask;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class FormLoginActivity extends AppCompatActivity {

    private EditText editEmail;
    private EditText editSenha;
    private Button btEntrar;
    private TextView textCrieConta;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form_login);

        inicializarComponentes();
        configurarListeners();
    }

    private void inicializarComponentes() {

        editEmail = findViewById(R.id.edit_email);
        editSenha = findViewById(R.id.edit_senha);
        btEntrar = findViewById(R.id.btn_entrar);
        textCrieConta = findViewById(R.id.text_crie_conta);
    }


    private void configurarListeners() {

        btEntrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                realizarLogin();
            }
        });

        textCrieConta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navegarParaCadastro();
            }
        });
    }

    private void realizarLogin() {
        String email = editEmail.getText().toString().trim();
        String senha = editSenha.getText().toString().trim();

        if (email.isEmpty()) {
            editEmail.setError("O campo E-mail é obrigatório.");
            editEmail.requestFocus();
            return;
        }
        if (senha.isEmpty()) {
            editSenha.setError("O campo Senha é obrigatório.");
            editSenha.requestFocus();
            return;
        }

        if (email.equals("teste@hightask.com") && senha.equals("123456")) {
            Toast.makeText(this, "Login realizado com sucesso!", Toast.LENGTH_SHORT).show();
            navegarParaMenu();
        } else {
            Toast.makeText(this, "Credenciais inválidas. Tente novamente.", Toast.LENGTH_LONG).show();
        }
    }

    private void navegarParaMenu() {
        Intent intent = new Intent(FormLoginActivity.this, FormMenu.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    private void navegarParaCadastro() {
        Intent intent = new Intent(FormLoginActivity.this, FormCadastro.class);
        startActivity(intent);
    }
}