package com.example.hightask;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

/**
 * Activity responsável por exibir a tela de Perfil do usuário.
 * Contém a lógica para deslogar do aplicativo e o funcionamento da seta para voltar ao Menu.
 */
public class TelaPincipal extends AppCompatActivity {

    private Button buttonDeslogar;
    private View iconVoltarMenu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_tela_pincipal);

        inicializarComponentes();
        configurarListeners();
    }

    private void inicializarComponentes() {
        buttonDeslogar = findViewById(R.id.btn_deslogar);

        iconVoltarMenu = findViewById(R.id.icon_voltar_menu);
    }

    private void configurarListeners() {

        buttonDeslogar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                realizarLogout();
            }
        });

        if (iconVoltarMenu != null) {
            iconVoltarMenu.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // O método finish() encerra a Activity atual e retorna para a anterior (Menu Principal)
                    finish();
                }
            });
        }
    }

    private void realizarLogout() {
        Toast.makeText(this, "Logout realizado com sucesso!", Toast.LENGTH_SHORT).show();

        Intent intent = new Intent(TelaPincipal.this, FormLoginActivity.class);

        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);

        startActivity(intent);

        finish();
    }
}