package com.example.hightask;

/**
 * Modelo de dados para representar um Chamado (Ticket) no sistema.
 * Contém informações essenciais como ID, título, prioridade e status.
 */
public class Chamado {
    private String id;
    private String titulo;
    private String descricao;
    private String prioridade; // Ex: Baixa, Media, Alta
    private String status;     // Ex: Aberto, Em Andamento, Fechado
    private String criador;
    private String dataHora;

    /**
     * Construtor completo para inicializar um novo objeto Chamado.
     */
    public Chamado(String id, String titulo, String descricao, String prioridade, String status, String criador, String dataHora) {
        this.id = id;
        this.titulo = titulo;
        this.descricao = descricao;
        this.prioridade = prioridade;
        this.status = status;
        this.criador = criador;
        this.dataHora = dataHora;
    }

    // --- Getters ---

    public String getId() { return id; }
    public String getTitulo() { return titulo; }
    public String getDescricao() { return descricao; }
    public String getPrioridade() { return prioridade; }
    public String getStatus() { return status; }
    public String getCriador() { return criador; }
    public String getDataHora() { return dataHora; }

    /**
     * Retorna uma representação em String do objeto Chamado, útil para logs.
     */
    @Override
    public String toString() {
        return "Chamado{" +
                "id='" + id + '\'' +
                ", titulo='" + titulo + '\'' +
                ", prioridade='" + prioridade + '\'' +
                ", status='" + status + '\'' +
                '}';
    }
}