package com.example.hightask;

public class SupabaseConfig {
    public static final String PROJECT_ID = "ikjvkwnsmjrsgmngutks";
    public static final String PUBLIC_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImlranZrd25zbWpyc2dtbmd1dGtzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTk5ODM2NjgsImV4cCI6MjA3NTU1OTY2OH0.5d7o6MJkBFZY4qhzOyTZC9cfLKGLJxqk-5mHUTKoh6c";
    public static final String API_BASE_URL =
            "https://" + PROJECT_ID + ".supabase.co/functions/v1/make-server-194bf14c/";
}