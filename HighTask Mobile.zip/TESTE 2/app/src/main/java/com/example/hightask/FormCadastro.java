package com.example.hightask;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;


public class FormCadastro extends AppCompatActivity {

    private EditText editNome;
    private EditText editEmail;
    private EditText editSenha;
    private Button btCadastrar;


    private static final int REGISTRATION_DELAY_MS = 2500;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_form_cadastro);

        inicializarComponentes();

        btCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                realizarCadastro();
            }
        });
    }

    private void inicializarComponentes() {

        editNome = findViewById(R.id.edit_nome);
        editEmail = findViewById(R.id.edit_email);
        editSenha = findViewById(R.id.edit_senha);
        btCadastrar = findViewById(R.id.btn_cadastrar);
    }

    private void realizarCadastro() {
        String nome = editNome.getText().toString().trim();
        String email = editEmail.getText().toString().trim();
        String senha = editSenha.getText().toString().trim();


        if (nome.isEmpty()) {
            Toast.makeText(this, "O campo Nome é obrigatório.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (email.isEmpty() || !email.contains("@")) {
            Toast.makeText(this, "E-mail inválido.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (senha.isEmpty() || senha.length() < 6) {
            Toast.makeText(this, "A senha deve ter pelo menos 6 caracteres.", Toast.LENGTH_SHORT).show();
            return;
        }


        btCadastrar.setEnabled(false);
        btCadastrar.setAlpha(0.5f);


        btCadastrar.postDelayed(new Runnable() {
            @Override
            public void run() {
                // Aqui você integraria a lógica real de criação de usuário (ex: Firebase Auth.createUserWithEmailAndPassword)

                // SIMULAÇÃO DE SUCESSO
                Toast.makeText(FormCadastro.this, "Usuário " + nome + " cadastrado com sucesso! Faça login.", Toast.LENGTH_LONG).show();

                // Retorna para a tela de Login, fechando a tela de Cadastro.
                finish();
            }
        }, REGISTRATION_DELAY_MS);
    }

}