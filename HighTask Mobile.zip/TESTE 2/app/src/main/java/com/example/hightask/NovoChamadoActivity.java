package com.example.hightask;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class NovoChamadoActivity extends AppCompatActivity {

    private EditText editTextTitulo;
    private EditText editTextDescricao;
    private Spinner spinnerPrioridade;
    private Spinner spinnerCategoria;
    private Button buttonEnviar;
    private Button buttonCancelar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form_chamados);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Novo Chamado");
        }

        inicializarComponentes();
        configurarSpinners();
        configurarListeners();
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

    private void inicializarComponentes() {
        editTextTitulo = findViewById(R.id.editTextTitulo);
        editTextDescricao = findViewById(R.id.editTextDescricao);
        spinnerPrioridade = findViewById(R.id.spinnerPrioridade);
        spinnerCategoria = findViewById(R.id.spinnerCategoria);
        buttonEnviar = findViewById(R.id.buttonEnviar);
        buttonCancelar = findViewById(R.id.buttonCancelar);
    }

    private void configurarSpinners() {

        String[] prioridades = {"Baixa", "Média", "Alta", "Urgente"};
        ArrayAdapter<String> adapterPrioridade = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, prioridades);
        adapterPrioridade.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerPrioridade.setAdapter(adapterPrioridade);

        String[] categorias = {"Hardware", "Software", "Rede", "Email", "Outros"};
        ArrayAdapter<String> adapterCategoria = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, categorias);
        adapterCategoria.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCategoria.setAdapter(adapterCategoria);
    }

    private void configurarListeners() {
        buttonEnviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                enviarChamado();
            }
        });

        buttonCancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                limparCampos();
                finish();
            }
        });
    }

    private void enviarChamado() {
        String titulo = editTextTitulo.getText().toString().trim();
        String descricao = editTextDescricao.getText().toString().trim();
        String prioridade = spinnerPrioridade.getSelectedItem().toString();
        String categoria = spinnerCategoria.getSelectedItem().toString();

        if (titulo.isEmpty()) {
            Toast.makeText(this, "Por favor, digite o título do chamado", Toast.LENGTH_SHORT).show();
            return;
        }

        if (descricao.isEmpty()) {
            Toast.makeText(this, "Por favor, descreva o problema", Toast.LENGTH_SHORT).show();
            return;
        }

        // Em um projeto real, aqui seria feito o envio para um banco de dados ou API
        Toast.makeText(this, "Chamado enviado com sucesso!\n" +
                "Título: " + titulo + "\n" +
                "Categoria: " + categoria + "\n" +
                "Prioridade: " + prioridade, Toast.LENGTH_LONG).show();

        limparCampos();
        finish();
    }

    private void limparCampos() {
        editTextTitulo.setText("");
        editTextDescricao.setText("");
        spinnerPrioridade.setSelection(0);
        spinnerCategoria.setSelection(0);
    }
}